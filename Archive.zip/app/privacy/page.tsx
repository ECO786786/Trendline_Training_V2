import PrivacyPolicy from "@/components/policies/PrivacyPolicy";

export default function Privacy() {
  return <PrivacyPolicy />;
}
