import Enrollment from "@/components/Enrollment";

export default function WorkShopEnrollment() {
  return (
    <>
      <Enrollment />
    </>
  );
}
