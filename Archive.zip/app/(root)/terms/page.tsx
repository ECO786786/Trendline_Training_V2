import TermsConditions from "@/components/policies/TermsCondtions";

export default function Terms() {
  return <TermsConditions />;
}
