import TrainingSchedule from "@/components/TrainingTimetable";

export default function TrainingSchedulePage() {
  return <TrainingSchedule />;
}
