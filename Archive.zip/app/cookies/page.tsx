import CookiesPolicy from "@/components/policies/CookiePolicy";

export default function Cookies() {
  return <CookiesPolicy />;
}
