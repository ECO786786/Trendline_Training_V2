export const whatsappNumber = process.env.NEXT_PUBLIC_WHATSAPPNUMBER;
