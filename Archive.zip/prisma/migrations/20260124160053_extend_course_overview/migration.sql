-- AlterTable
ALTER TABLE `Course` MODIFY `overview` TEXT NOT NULL;
